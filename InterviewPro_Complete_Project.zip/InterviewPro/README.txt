INTERVIEWPRO - SETUP GUIDE

1. Install Python 3.10 or newer.
2. Open this folder in VS Code.
3. Open Terminal > New Terminal.
4. Create a virtual environment:
   Windows: py -m venv venv
5. Activate it:
   PowerShell: .\venv\Scripts\Activate.ps1
   Command Prompt: venv\Scripts\activate.bat
6. Install packages:
   py -m pip install -r requirements.txt
7. Configure AI:
   Copy .env.example to .env and add your OpenAI API key.
   python-dotenv is included in requirements.txt, so the .env file loads automatically.
   Alternatively, set environment variables in the terminal:
       PowerShell: $env:OPENAI_API_KEY="your_key"
       CMD: set OPENAI_API_KEY=your_key
   Never share your API key or put it in script.js.
8. Run:
   py app.py
9. Open:
   http://127.0.0.1:5000

Without an API key, the site still runs using sample questions and a clearly
labelled local heuristic evaluation. This fallback is NOT genuine AI evaluation.

The website is a learning/demo project. Automated feedback is for practice,
not an official employer assessment. Do not upload sensitive personal data.
