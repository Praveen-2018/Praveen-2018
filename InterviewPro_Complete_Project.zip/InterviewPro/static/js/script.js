document.addEventListener("DOMContentLoaded", () => {
  const menu = document.getElementById("menuToggle");
  const nav = document.getElementById("mainNav");
  if (menu && nav) menu.addEventListener("click", () => nav.classList.toggle("open"));

  document.querySelectorAll(".bookmark-btn").forEach(btn => {
    btn.addEventListener("click", async () => {
      try {
        const res = await fetch("/api/bookmark", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({question:btn.dataset.question, subject:btn.dataset.subject})});
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Could not save bookmark");
        btn.textContent = data.saved ? "★ Saved" : "☆ Bookmark";
      } catch (e) { alert(e.message); }
    });
  });

  document.querySelectorAll(".save-reflection").forEach((btn, i) => {
    btn.addEventListener("click", () => {
      const area = btn.parentElement.querySelector(".reflection");
      const key = "interviewpro-reflection-" + i;
      localStorage.setItem(key, area.value);
      btn.parentElement.querySelector(".save-state").textContent = "Saved in this browser.";
    });
  });
  document.querySelectorAll(".reflection").forEach((area, i) => {
    area.value = localStorage.getItem("interviewpro-reflection-" + i) || "";
  });

  const setup = document.getElementById("interviewSetup");
  if (!setup) return;
  const messages = document.getElementById("chatMessages");
  const answerInput = document.getElementById("answerInput");
  const send = document.getElementById("sendAnswer");
  const finish = document.getElementById("finishInterview");
  const status = document.getElementById("chatStatus");
  const progress = document.getElementById("questionProgress");
  let interviewId = null, questions = [], current = 0, busy = false;

  function bubble(text, who="bot") {
    const div = document.createElement("div");
    div.className = "chat-bubble " + who;
    div.textContent = text;
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
  }
  function showFeedback(f) {
    const wrap = document.createElement("div");
    wrap.className = "feedback-card";
    const heading = document.createElement("b");
    heading.textContent = `Feedback · ${f.score ?? 0}/100 · ${f.evaluation_mode || "Practice feedback"}`;
    const p = document.createElement("p");
    p.textContent = `${f.correctness || ""} ${f.relevance || ""} ${f.clarity || ""}`;
    const list = document.createElement("p");
    list.textContent = "Improve: " + (f.improvements || []).join("; ");
    wrap.append(heading,p,list);
    messages.appendChild(wrap);
    messages.scrollTop = messages.scrollHeight;
    if (f.ideal_answer) bubble("Suggested answer: " + f.ideal_answer);
    if (f.follow_up) bubble("Follow-up to think about: " + f.follow_up);
  }
  function askCurrent() {
    if (current >= questions.length) {
      answerInput.disabled = true; send.disabled = true; finish.disabled = false;
      status.textContent = "All questions answered";
      bubble("You have completed all questions. Select Finish interview to generate your report.");
      return;
    }
    bubble(`Question ${current+1} of ${questions.length}: ${questions[current]}`);
    progress.textContent = `Question ${current+1} of ${questions.length}`;
    answerInput.disabled = false; send.disabled = false; answerInput.focus();
  }
  setup.addEventListener("submit", async e => {
    e.preventDefault();
    if (busy) return;
    busy = true;
    const form = Object.fromEntries(new FormData(setup).entries());
    status.textContent = "Preparing your interview...";
    try {
      const res = await fetch(window.INTERVIEW_ENDPOINTS.start, {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)});
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Unable to start interview");
      interviewId = data.interview_id; questions = data.questions; current = 0;
      messages.innerHTML = "";
      bubble(`Your ${form.category} practice interview for ${form.role} is ready. Mode: ${data.mode}. Take your time and answer in your own words.`);
      status.textContent = "Interview in progress";
      setup.querySelector("button[type=submit]").disabled = true;
      askCurrent();
    } catch(err) { bubble(err.message); status.textContent = "Could not start"; }
    finally { busy = false; }
  });
  async function submitAnswer() {
    const answer = answerInput.value.trim();
    if (!answer || busy || !interviewId) return;
    busy = true; send.disabled = true; answerInput.disabled = true;
    bubble(answer, "student");
    answerInput.value = "";
    status.textContent = "Evaluating your answer...";
    try {
      const res = await fetch(window.INTERVIEW_ENDPOINTS.answer, {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({interview_id:interviewId,index:current,answer})});
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not submit answer");
      showFeedback(data.feedback); current++;
      status.textContent = "Feedback received";
      askCurrent();
    } catch(err) { bubble(err.message); answerInput.disabled = false; send.disabled = false; }
    finally { busy = false; }
  }
  send.addEventListener("click", submitAnswer);
  answerInput.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submitAnswer(); }});
  finish.addEventListener("click", async () => {
    if (!interviewId || busy) return;
    busy = true; finish.disabled = true; status.textContent = "Generating report...";
    try {
      const res = await fetch(window.INTERVIEW_ENDPOINTS.finish, {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({interview_id:interviewId})});
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not generate report");
      window.location.href = data.redirect;
    } catch(err) { bubble(err.message); finish.disabled = false; }
    finally { busy = false; }
  });
});
