import os
import json
import sqlite3
import secrets
from datetime import datetime
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_file
from werkzeug.security import generate_password_hash, check_password_hash

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "database.db")

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "change-this-development-secret-" + secrets.token_hex(8))
app.config["MAX_CONTENT_LENGTH"] = 3 * 1024 * 1024


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            college TEXT DEFAULT '',
            branch TEXT DEFAULT '',
            year TEXT DEFAULT '',
            skills TEXT DEFAULT '',
            target_company TEXT DEFAULT '',
            preferred_role TEXT DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS interviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            category TEXT NOT NULL,
            company TEXT NOT NULL,
            role TEXT NOT NULL,
            difficulty TEXT NOT NULL,
            question_count INTEGER NOT NULL,
            questions_json TEXT NOT NULL,
            answers_json TEXT NOT NULL DEFAULT '[]',
            report_json TEXT DEFAULT '',
            score INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS bookmarks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            question TEXT NOT NULL,
            subject TEXT NOT NULL,
            UNIQUE(user_id, question),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        """)
    seed_questions()


QUESTION_BANK = [
    ("Python", "Beginner", "What is the difference between a list and a tuple in Python?", "A list is mutable, so its contents can be changed. A tuple is immutable after creation."),
    ("Python", "Intermediate", "Explain Python decorators.", "A decorator is a callable that wraps another function to extend or modify its behaviour without changing its source code."),
    ("Java", "Beginner", "What is the difference between JDK, JRE and JVM?", "JVM executes bytecode, JRE provides the JVM and runtime libraries, and JDK includes the JRE plus development tools."),
    ("C Programming", "Beginner", "What is a pointer in C?", "A pointer is a variable that stores the memory address of another variable."),
    ("DSA", "Intermediate", "How does binary search work and what is its time complexity?", "Binary search repeatedly halves a sorted search range. Its time complexity is O(log n)."),
    ("DBMS", "Beginner", "What is database normalization?", "Normalization organizes relational data to reduce redundancy and improve data integrity."),
    ("Operating Systems", "Intermediate", "What is the difference between a process and a thread?", "A process is an executing program with its own address space; threads are execution paths within a process and share its resources."),
    ("Computer Networks", "Beginner", "Explain the purpose of the OSI model.", "The OSI model divides network communication into seven layers, making network functions easier to design and troubleshoot."),
    ("SQL", "Beginner", "What is the difference between WHERE and HAVING?", "WHERE filters rows before grouping; HAVING filters groups after GROUP BY."),
    ("Artificial Intelligence", "Intermediate", "What is the difference between AI, machine learning and deep learning?", "AI is the broad field of intelligent systems; ML learns patterns from data; deep learning uses multi-layer neural networks."),
    ("Machine Learning", "Intermediate", "What is overfitting and how can it be reduced?", "Overfitting occurs when a model learns training data too closely and generalizes poorly. Regularization, cross-validation and more data can help."),
    ("HR", "Beginner", "Tell me about yourself.", "Give a concise introduction covering your education, relevant skills, one project or achievement, and the role you are seeking."),
    ("HR", "Beginner", "What are your strengths and weaknesses?", "Choose job-relevant strengths with evidence and one genuine development area with steps you are taking to improve."),
    ("HR", "Intermediate", "Describe a challenging situation and how you handled it.", "Use the STAR method: Situation, Task, Action and Result. Explain your own contribution and what you learned."),
    ("Coding", "Beginner", "How would you find the largest element in an array?", "Initialize a maximum with the first element, scan the remaining elements and update the maximum when a larger value is found. O(n) time."),
    ("Coding", "Intermediate", "How can you check whether a string is a palindrome?", "Compare characters from both ends moving inward, or compare the string with its reverse. A two-pointer approach uses O(1) extra space.")
]


def seed_questions():
    with get_db() as db:
        count = db.execute("SELECT COUNT(*) AS n FROM question_bank").fetchone() if table_exists(db, "question_bank") else None
        if not count:
            db.execute("""CREATE TABLE IF NOT EXISTS question_bank (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                subject TEXT NOT NULL, difficulty TEXT NOT NULL,
                question TEXT NOT NULL, answer TEXT NOT NULL
            )""")
        count = db.execute("SELECT COUNT(*) AS n FROM question_bank").fetchone()["n"]
        if count == 0:
            db.executemany("INSERT INTO question_bank(subject,difficulty,question,answer) VALUES(?,?,?,?)", QUESTION_BANK)


def table_exists(db, name):
    return db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone() is not None


def current_user():
    if "user_id" not in session:
        return None
    with get_db() as db:
        return db.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper


def ai_client():
    key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not key or OpenAI is None:
        return None
    return OpenAI(api_key=key)


def ask_ai(system_prompt, user_prompt):
    client = ai_client()
    if client is None:
        return None
    try:
        response = client.chat.completions.create(
            model=os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.6
        )
        return response.choices[0].message.content.strip()
    except Exception as exc:
        app.logger.exception("AI request failed: %s", exc)
        return None


def parse_json_response(raw):
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        start, end = raw.find("{"), raw.rfind("}")
        if start >= 0 and end > start:
            try:
                return json.loads(raw[start:end+1])
            except json.JSONDecodeError:
                return None
    return None


@app.context_processor
def inject_globals():
    return {"logged_user": current_user(), "ai_enabled": bool(os.environ.get("OPENAI_API_KEY"))}


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 8:
            flash("Enter your name, a valid email and a password with at least 8 characters.", "danger")
            return render_template("register.html")
        try:
            with get_db() as db:
                cur = db.execute("""INSERT INTO users(name,email,password_hash,created_at)
                    VALUES(?,?,?,?)""", (name, email, generate_password_hash(password), datetime.now().isoformat(timespec="seconds")))
                session["user_id"] = cur.lastrowid
            flash("Your account has been created. Welcome to InterviewPro!", "success")
            return redirect(url_for("dashboard"))
        except sqlite3.IntegrityError:
            flash("An account with that email already exists.", "danger")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        with get_db() as db:
            user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            flash("Welcome back!", "success")
            return redirect(url_for("dashboard"))
        flash("Incorrect email or password.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))


@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    with get_db() as db:
        rows = db.execute("SELECT * FROM interviews WHERE user_id=? ORDER BY id DESC", (user["id"],)).fetchall()
    scores = [r["score"] for r in rows]
    average = round(sum(scores) / len(scores)) if scores else 0
    return render_template("dashboard.html", user=user, interviews=rows[:6],
                           total=len(rows), average=average)


@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    user = current_user()
    if request.method == "POST":
        fields = [request.form.get(k, "").strip() for k in
                  ("college", "branch", "year", "skills", "target_company", "preferred_role")]
        with get_db() as db:
            db.execute("""UPDATE users SET college=?,branch=?,year=?,skills=?,target_company=?,preferred_role=?
                          WHERE id=?""", (*fields, user["id"]))
        flash("Profile updated.", "success")
        return redirect(url_for("profile"))
    return render_template("profile.html", user=user)


@app.route("/interview")
@login_required
def interview():
    return render_template("interview.html")


@app.route("/api/start-interview", methods=["POST"])
@login_required
def api_start_interview():
    data = request.get_json(silent=True) or {}
    category = data.get("category", "Technical")
    company = data.get("company", "General")
    role = data.get("role", "Software Developer")
    difficulty = data.get("difficulty", "Beginner")
    try:
        count = int(data.get("count", 5))
    except (ValueError, TypeError):
        count = 5
    count = min(15, max(5, count))
    if category not in ["Technical", "HR", "Coding", "Company-specific"]:
        return jsonify(error="Invalid interview category."), 400
    if difficulty not in ["Beginner", "Intermediate", "Advanced"]:
        return jsonify(error="Invalid difficulty."), 400

    system = ("You are a supportive but realistic placement interviewer. Create concise, relevant interview questions. "
              "Return ONLY valid JSON with a 'questions' array of exactly the requested number of strings. "
              "Do not claim these are actual or guaranteed company questions.")
    prompt = f"Create {count} {difficulty} difficulty {category} interview questions for a {role} candidate preparing for {company}. Include a sensible mix appropriate to the category. JSON format: {{\"questions\":[...]}}"
    parsed = parse_json_response(ask_ai(system, prompt))
    questions = parsed.get("questions", []) if parsed else []
    if len(questions) < count:
        with get_db() as db:
            if category == "HR":
                rows = db.execute("SELECT question FROM question_bank WHERE subject='HR'").fetchall()
            elif category == "Coding":
                rows = db.execute("SELECT question FROM question_bank WHERE subject IN ('Coding','DSA')").fetchall()
            else:
                rows = db.execute("SELECT question FROM question_bank WHERE subject NOT IN ('HR')").fetchall()
        fallback = [r["question"] for r in rows]
        while len(questions) < count:
            questions.append(fallback[len(questions) % len(fallback)] if fallback else "Describe a technical concept you know well.")
    questions = questions[:count]
    with get_db() as db:
        cur = db.execute("""INSERT INTO interviews(user_id,category,company,role,difficulty,question_count,
            questions_json,answers_json,created_at) VALUES(?,?,?,?,?,?,?,?,?)""",
            (current_user()["id"], category, company, role, difficulty, count,
             json.dumps(questions), "[]", datetime.now().isoformat(timespec="seconds")))
        interview_id = cur.lastrowid
    return jsonify(interview_id=interview_id, questions=questions,
                   ai_enabled=ai_client() is not None,
                   mode="AI-powered" if ai_client() else "Question-bank fallback")


@app.route("/api/answer", methods=["POST"])
@login_required
def api_answer():
    data = request.get_json(silent=True) or {}
    interview_id = data.get("interview_id")
    index = data.get("index")
    answer = (data.get("answer") or "").strip()
    if not answer:
        return jsonify(error="Please enter an answer before submitting."), 400
    with get_db() as db:
        record = db.execute("SELECT * FROM interviews WHERE id=? AND user_id=?",
                            (interview_id, current_user()["id"])).fetchone()
        if not record:
            return jsonify(error="Interview not found."), 404
        questions = json.loads(record["questions_json"])
        answers = json.loads(record["answers_json"] or "[]")
        if not isinstance(index, int) or index < 0 or index >= len(questions):
            return jsonify(error="Invalid question number."), 400
        if index < len(answers):
            return jsonify(error="This question has already been answered."), 400
        if index != len(answers):
            return jsonify(error="Please answer the current question in order."), 400
        question = questions[index]

    system = ("You are an experienced student placement interview coach. Evaluate fairly and constructively. "
              "Return ONLY JSON with keys score (integer 0-100), correctness, relevance, clarity, completeness, "
              "strengths (array of strings), improvements (array of strings), ideal_answer, follow_up. "
              "Do not reward unsupported claims. If the answer is blank or irrelevant, score it low.")
    prompt = f"Interview category: {record['category']}\nDifficulty: {record['difficulty']}\nQuestion: {question}\nStudent answer: {answer}\nEvaluate this answer."
    result = parse_json_response(ask_ai(system, prompt))
    if result is None:
        # Clearly labelled local fallback; not represented as AI evaluation.
        words = set(answer.lower().replace(".", " ").replace(",", " ").split())
        score = min(85, max(15, 25 + min(len(words), 35)))
        result = {
            "score": score,
            "correctness": "A basic local heuristic was used; connect the AI API for semantic evaluation.",
            "relevance": "Review whether your answer directly addresses the question.",
            "clarity": "Use short, structured sentences and explain important terms.",
            "completeness": "Add a concrete example and cover the key points.",
            "strengths": ["You attempted the question.", "Your response contains " + str(len(words)) + " distinct words."],
            "improvements": ["Add accurate technical details.", "Include an example or practical application."],
            "ideal_answer": "A model-generated ideal answer will appear here when the AI API is configured. Use your notes or question bank to practise.",
            "follow_up": "Can you give a practical example related to your answer?"
        }
        result["evaluation_mode"] = "Local practice heuristic (not AI)"
    else:
        result["evaluation_mode"] = "AI evaluation"
    answer_item = {"question": question, "answer": answer, "feedback": result}
    with get_db() as db:
        fresh = db.execute("SELECT answers_json FROM interviews WHERE id=?", (interview_id,)).fetchone()
        answers = json.loads(fresh["answers_json"] or "[]")
        answers.append(answer_item)
        db.execute("UPDATE interviews SET answers_json=? WHERE id=?", (json.dumps(answers), interview_id))
    return jsonify(feedback=result, completed=len(answers) >= len(questions), answered=len(answers), total=len(questions))


@app.route("/api/finish-interview", methods=["POST"])
@login_required
def api_finish_interview():
    data = request.get_json(silent=True) or {}
    interview_id = data.get("interview_id")
    with get_db() as db:
        record = db.execute("SELECT * FROM interviews WHERE id=? AND user_id=?",
                            (interview_id, current_user()["id"])).fetchone()
        if not record:
            return jsonify(error="Interview not found."), 404
        answers = json.loads(record["answers_json"] or "[]")
        if not answers:
            return jsonify(error="Answer at least one question to generate a report."), 400
        scores = [int(a["feedback"].get("score", 0)) for a in answers]
        average = round(sum(scores) / len(scores))
        summary = {
            "score": average,
            "answered": len(answers),
            "total": record["question_count"],
            "strengths": list(dict.fromkeys(s for a in answers for s in a["feedback"].get("strengths", [])))[:5],
            "improvements": list(dict.fromkeys(s for a in answers for s in a["feedback"].get("improvements", [])))[:5],
            "recommendation": "Review the questions where your score was lowest, practise explaining concepts aloud, and attempt another mock interview."
        }
        db.execute("UPDATE interviews SET score=?,report_json=? WHERE id=?",
                   (average, json.dumps(summary), interview_id))
    return jsonify(report=summary, redirect=url_for("report", interview_id=interview_id))


@app.route("/report/<int:interview_id>")
@login_required
def report(interview_id):
    with get_db() as db:
        record = db.execute("SELECT * FROM interviews WHERE id=? AND user_id=?",
                            (interview_id, current_user()["id"])).fetchone()
    if not record:
        flash("Report not found.", "danger")
        return redirect(url_for("dashboard"))
    answers = json.loads(record["answers_json"] or "[]")
    summary = json.loads(record["report_json"] or "{}")
    return render_template("report.html", record=record, answers=answers, summary=summary)


@app.route("/questions")
@login_required
def questions():
    subject = request.args.get("subject", "All")
    difficulty = request.args.get("difficulty", "All")
    search = request.args.get("q", "").strip()
    query = "SELECT * FROM question_bank WHERE 1=1"
    params = []
    if subject != "All":
        query += " AND subject=?"
        params.append(subject)
    if difficulty != "All":
        query += " AND difficulty=?"
        params.append(difficulty)
    if search:
        query += " AND question LIKE ?"
        params.append("%" + search + "%")
    query += " ORDER BY subject, id"
    with get_db() as db:
        rows = db.execute(query, params).fetchall()
        subjects = [r["subject"] for r in db.execute("SELECT DISTINCT subject FROM question_bank ORDER BY subject")]
        bookmarks = {r["question"] for r in db.execute("SELECT question FROM bookmarks WHERE user_id=?", (current_user()["id"],))}
    return render_template("questions.html", questions=rows, subjects=subjects,
                           selected_subject=subject, selected_difficulty=difficulty,
                           search=search, bookmarks=bookmarks)


@app.route("/coding")
@login_required
def coding():
    with get_db() as db:
        rows = db.execute("SELECT * FROM question_bank WHERE subject IN ('Coding','DSA') ORDER BY id").fetchall()
    return render_template("coding.html", questions=rows)


@app.route("/api/bookmark", methods=["POST"])
@login_required
def bookmark():
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()
    subject = (data.get("subject") or "General").strip()
    if not question:
        return jsonify(error="Question is required."), 400
    with get_db() as db:
        existing = db.execute("SELECT id FROM bookmarks WHERE user_id=? AND question=?",
                              (current_user()["id"], question)).fetchone()
        if existing:
            db.execute("DELETE FROM bookmarks WHERE id=?", (existing["id"],))
            saved = False
        else:
            db.execute("INSERT INTO bookmarks(user_id,question,subject) VALUES(?,?,?)",
                       (current_user()["id"], question, subject))
            saved = True
    return jsonify(saved=saved)


@app.route("/api/history")
@login_required
def history():
    with get_db() as db:
        rows = db.execute("SELECT id,category,company,role,difficulty,score,created_at FROM interviews WHERE user_id=? ORDER BY id DESC",
                          (current_user()["id"],)).fetchall()
    return jsonify(items=[dict(r) for r in rows])


@app.route("/health")
def health():
    return jsonify(status="ok", ai_configured=ai_client() is not None)


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
